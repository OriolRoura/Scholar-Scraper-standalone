from .ScholarScraper import ScholarScraper

scholar_scraper = ScholarScraper()
