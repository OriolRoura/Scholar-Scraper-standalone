Scholar Scraper 

Purpose

Requirements
  ```powershell
  python -m venv .venv
  .\.venv\Scripts\Activate.ps1
  pip install -r requirements.txt
  ```
  ```powershell
  pip install selenium webdriver-manager
  ```

Configuration
The scraper uses un fitxer `config.json` per definir el seu comportament. Exemple:
  ```json
  {
    "results_file": "results.json",           
    "rescrape_threshold_days": 7,            
    "scholar_ids": ["xxxxxxxx"]          
  }
  ```
- Ajusta aquests paràmetres segons les teves necessitats abans d'executar el scraper.
Quick run
- Run the scraper from the repo root:
  .\.venv\Scripts\Activate.ps1
  python scraper.py
  ```

Main outputs
- `results.json` — scraped authors and publications (merged/stamped by the utilities helper).
- `.cache/last_solved_session.json` — optional cached cookies/localStorage produced by the manual-solve helper.

CAPTCHA behavior (short)
- If Google serves a CAPTCHA the scraper can open a real browser so you can solve it manually. After you solve it, the helper saves cookies to `.cache/last_solved_session.json` so future runs can reuse them.
- Selenium is optional: without Selenium the scraper cannot automatically open a browser for you. You can still run the scraper, but if a CAPTCHA appears you'll need to manually open a browser, solve it, and export cookies to the canonical cache file yourself.
