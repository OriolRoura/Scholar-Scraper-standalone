# validate_session_detailed.py
import os, json, requests
from datetime import datetime
repo_root = os.path.abspath(os.path.dirname(__file__))
cache = os.path.join(repo_root, '.cache', 'last_solved_session.json')

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'DNT': '1',
    'Referer': 'https://scholar.google.com/'
}

if not os.path.exists(cache):
    print('No cache at', cache)
    raise SystemExit(1)

with open(cache, 'r', encoding='utf8') as f:
    payload = json.load(f)
cookies = payload.get('cookies', [])

print('Saved cookies (name, domain, expiry):')
for c in cookies:
    print('-', c.get('name'), c.get('domain'), c.get('expiry'),
          '->', datetime.fromtimestamp(c.get('expiry')) if c.get('expiry') else 'no-expiry')

s = requests.Session()
for c in cookies:
    try:
        ck = requests.cookies.create_cookie(
            name=c.get('name'),
            value=c.get('value'),
            domain=c.get('domain'),
            path=c.get('path', '/'),
            expires=c.get('expiry')
        )
        s.cookies.set_cookie(ck)
    except Exception as ex:
        print('Failed to create cookie', c.get('name'), ex)

# print cookies that will be sent to the domain
print('\nCookie jar contents:')
for cookie in s.cookies:
    print('-', cookie.name, cookie.domain, 'expires=', getattr(cookie, 'expires', None))

url = 'https://scholar.google.com/citations?hl=en&user=L8dhqAsAAAAJ&pagesize=100'
print('\nSending GET with browser-like headers...')
r = s.get(url, headers=headers, allow_redirects=True, timeout=20)
print('Status:', r.status_code)
print('Final URL:', r.url)
print('Response headers (sample):')
for k in ('content-type', 'cache-control', 'set-cookie'):
    if k in r.headers:
        print(' ', k, ':', r.headers[k])
print('\nResponse body snippet (200 chars):')
print((r.text or '')[:200])
if r.status_code in (429, 302) or 'sorry' in r.url or 'captcha' in (r.text or '').lower():
    print('\nValidation: blocked (captcha/429)')
else:
    print('\nValidation: OK (no immediate captcha)')